#include<stdio.h>
   void main (){
   	float num1, num2, num3, num4, num5,sum,average;
   	printf("Enter five number:\n");
   	scanf("%f %f %f %f  %f", &num1, &num2, &num3, &num4,   &num5);
   	 
    sum = num1 + num2 + num3 + num4 + num5;
    
    average = sum/5;
    printf("The average of a five number is :%.2f\n",average);
    
   }