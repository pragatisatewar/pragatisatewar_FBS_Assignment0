#include<stdio.h>
  void main(){
  	 int l,w,p;
  	 l = 10;
  	 w = 30;
     p = 2*(l+w);
  	 printf("%d",p);
	   
  }
  	