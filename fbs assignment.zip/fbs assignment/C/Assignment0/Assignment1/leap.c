#include<stdio.h>
  void main ()
  {
  	 int year = 2003;
  	if (" year % 4 ")
  	{
  		printf("%d year is a leap");
	  }
	   else
	   {
	   	printf("%d  year is a not leap");
	   }
  }
  