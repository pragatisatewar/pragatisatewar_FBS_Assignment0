#include<stdio.h>
  void main ()
  {
  	 int no = 4;
  	 
  	 if("no %2")
  	 {
  	 	printf("%d  no is a even");
  	 	
	   }
	   else
	   {
	   	printf("%d no is a odd ");
	   	
	   }
	     }