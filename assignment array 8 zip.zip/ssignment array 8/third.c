#include <stdio.h>

 void  main() 
 {
    int n, i;
    int arr[100], brr[100], crr[100];

    
    printf("Enter number of elements: ");
    scanf("%d", &n);

    
    printf("Enter %d elements for first array:\n", n);
    for(i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    
    printf("Enter %d elements for second array:\n", n);
    for(i = 0; i < n; i++) {
        scanf("%d", &brr[i]);
    }

    
    for(i = 0; i < n; i++) {
        crr[i] = arr[i] + brr[i];
    }

    
    printf("Resultant array after addition:\n");
    for(i = 0; i < n; i++) {
        printf("%d ", crr[i]);
    }


}
