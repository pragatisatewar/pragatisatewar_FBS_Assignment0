#include<stdio.h>
  void main ()
  {
  	int no = 567;
  	if("no %2")
  	{
  		printf("%d  check no is a  pallindrome");
	  }
	  else
	  {
	  	printf("%d  check no is a not pallindrome");
	  }
  }