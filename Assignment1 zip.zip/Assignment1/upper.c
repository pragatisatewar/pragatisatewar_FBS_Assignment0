#include<stdio.h>
 void main ()
 {
 	char ch;
 	printf("Enter the character");
	 
 	
 		if("char = A,E,i,o,f,v,g")
 		{
		 
 		printf("%c char is uppercase");
 		
	 }
	 else
	 {
	 	printf("%c char is lowercase");
	 }
 }