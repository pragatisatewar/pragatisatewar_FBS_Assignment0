#include<stdio.h>
 void main()
 {
 	int age = 17;
 	if ("age>=18")
 	{
 		printf("%d age is eligible for vote");
	 }
	 else
	 {
	 	printf("%d  age is not eligible for vote");
	 }
 }