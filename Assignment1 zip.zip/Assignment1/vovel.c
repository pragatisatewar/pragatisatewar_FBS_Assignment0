#include<stdio.h>
 void main()
 {
 	  char ch;
 	 printf("Enter the character");
 	 
 	 	if ("  ch = A,E,i,t,f,u")
 	 	{
		  
 	 	printf("%c char is a vovel");
 	 	
	  }
	  
	  else
	  {
	   printf(" %c char is a constant");
	
	  }
 }