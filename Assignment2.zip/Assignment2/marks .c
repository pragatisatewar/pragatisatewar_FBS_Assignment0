#include <stdio.h>

void  main() {
    int marks;

    
    printf("Enter marks: ");
    scanf("%d", &marks);

    
    if (marks >= 75) {
        printf("Distinction\n");
    }
    else {
        printf("Not Distinction\n");
    }

    if (marks >= 60 )
	 {
        printf("First Class\n");
    }
    else {
        printf("Not First Class\n");
    }

    if (marks >= 55 )
	 {
        printf("Second Class\n");
    }
    else {
        printf("Not Second Class\n");
    }

    if (marks >= 45) 
	{
        printf("Pass Class\n");
    }
    else {
        printf("Not Pass Class\n");
    }

    if (marks < 40) {
        printf("Fail\n");
    }
    else {
        printf("Not Fail\n");
    }

    return 0;
}
