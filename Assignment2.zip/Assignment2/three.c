#include<stdio.h>
 void main()
 {
 	int a = 20, b = 10,c = 30;
 	if (a>b)
 	{
 		if (a>c)
		 {
 			printf(" a is a greater");
	}
		 else
		 {
		 	printf(" c is a greater");
	}
		 if (b>c)
		 {
		 	printf("b is a greater");
		 }
 		 else
		 {
		 	printf(" c is a greater");
	}
	 }
}