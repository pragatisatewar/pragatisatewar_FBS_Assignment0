#include <stdio.h>

void main() {
    int age;

    
    printf("Enter age: ");
    scanf("%d",&age);

    
    if (age<12)
	 {
        printf("child\n");
    }
    else {
        printf("Not child\n");
    }

    if (age= 2-19)
	 {
        printf("Teenager\n");
    }
    else {
        printf("Not teenager\n");
    }

    if ( age=  20-59)
	 {
        printf("Adult\n");
    }
    else {
        printf("Not Adult\n");
    }

    if (age>=60)
	 {
        printf("Senior\n");
    }
    else {
        printf("Not Senior\n");
    }

     
}
