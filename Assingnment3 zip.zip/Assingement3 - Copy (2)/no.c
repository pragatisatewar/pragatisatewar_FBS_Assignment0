#include<stdio.h>
 void main()
 {
 	int z = 1;
 	while(z<=10)
 	{
 		printf("%d\n",z);
 		z++;
	 }
 }
