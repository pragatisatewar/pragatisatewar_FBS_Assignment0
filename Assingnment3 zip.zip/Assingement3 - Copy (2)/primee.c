#include <stdio.h>

  void main() {
    int n, i = 2, j, flag;

    printf("Enter the range (n): ");
    scanf("%d", &n);

    printf("Prime numbers between 1 and %d are:\n", n);

    while (i <= n) {
        flag = 1;  

        if (i == 1) {
            flag = 0; 
        } else {
            j = 2;
            while (j <= i / 2) {
                if (i % j == 0) {
                    flag = 0; 
                    break;
                }
                j++;
            }
        }

        if (flag == 1) {
            printf("%d\n", i);
        }
        i++;
    }

    
}
