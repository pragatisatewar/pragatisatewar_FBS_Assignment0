#include <stdio.h>

int main() {
    int n, original, remainder, sum = 0;

    printf("Enter a number: ");
    scanf("%d", &n);

    original = n;   

    while (n != 0) {
        remainder = n % 10;             
        sum = sum + (remainder * remainder * remainder); // cube and add
        n = n / 10;                       
    }

    if (original == sum) {
        printf("Armstrong\n");
    } else {
        printf("Not Armstrong\n");
    }

    
}
