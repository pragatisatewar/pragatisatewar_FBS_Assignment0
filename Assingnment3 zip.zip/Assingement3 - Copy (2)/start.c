#include <stdio.h>

 void main()
  {
    int start, end;
    int sum = 0;

    printf("Enter start value: ");
    scanf("%d", &start);

    printf("Enter end value: ");
    scanf("%d", &end);

    int i = start;  

    while (i <= end) {   
        sum = sum + i;   
        i++;             
    }

    printf("Sum = %d\n", sum);

    
}
