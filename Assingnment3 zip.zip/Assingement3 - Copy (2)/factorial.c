#include <stdio.h>

int main() {
    int n, fact = 1, i = 1;

    printf("Enter a number: ");
    scanf("%d", &n);

    for  (i = 1;i <= n;i++) {
        fact = fact * i;  // multiply
        i++;
    }

    printf("Factorial = %d\n", fact);

    
}