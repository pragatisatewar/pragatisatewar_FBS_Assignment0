#include <stdio.h>

 void main() {
    int n, original, remainder, sum = 0, fact, i;

    printf("Enter a number: ");
    scanf("%d", &n);

    original = n;  

    while (n != 0) {
        remainder = n % 10;   

        // calculate factorial of remainder
        fact = 1;
        i = 1;
        while (i <= remainder) {
            fact = fact * i;
            i++;
        }

        sum = sum + fact;  
        n = n / 10;         
    }

    if (sum == original) {
        printf("Strong\n");
    } else {
        printf("Not Strong\n");
    }

}
