#include <stdio.h>

void  main() {
    int n, first, last, sum;

    printf("Enter a number: ");
    scanf("%d", &n);

    last = n % 10;   // last digit

    
    first = n;
    while (first >= 10) {
        first = first / 10;
    }

    sum = first + last;

    printf("Sum of first and last digit = %d\n", sum);

}
