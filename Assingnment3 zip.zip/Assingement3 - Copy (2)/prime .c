#include <stdio.h>

int main() {
    int n, i = 2, isPrime = 1;   // assume number is prime

    printf("Enter a number: ");
    scanf("%d", &n);

    if (n <= 1) {
        isPrime = 0;   
    } else {
        while (i <= n / 2) {   // check divisibility till n/2
            if (n % i == 0) {
                isPrime = 0;   // found a divisor
                break;         // stop checking
            }
            i++;
        }
    }

    if (isPrime == 1) {
        printf("Prime\n");
    } else {
        printf("Not Prime\n");
    }

    
}
