#include <stdio.h>

 void main() {
    int n, original, remainder, reversed = 0;

    printf("Enter a number: ");
    scanf("%d", &n);

    original = n;  

    while (n != 0) {
        remainder = n % 10;               
        reversed = reversed * 10 + remainder; 
        n = n / 10;                       
    }

    if (original == reversed) {
        printf("Palindrome\n");
    } else {
        printf("Not Palindrome\n");
    }

    
}
