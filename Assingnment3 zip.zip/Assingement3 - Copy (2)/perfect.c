#include <stdio.h>

void  main()
 {
    int n, i = 1, sum = 0;

    printf("Enter a number: ");
    scanf("%d", &n);

    while (i <= n / 2) {   // divisors are always less than or equal to n/2
        if (n % i == 0) {
            sum = sum + i; // add divisor 
        }
        i++;
    }

    if (sum == n) {
        printf("Perfect\n");
    } else {
        printf("Not Perfect\n");
    }

     
}
