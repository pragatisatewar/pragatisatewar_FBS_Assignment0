#include<stdio.h>
  void main(){
  	  int base,height,area;
  	  base  = 5;
  	  height = 10;
  	  area = (1/2*base*height);
  	  printf("%d",area);
  	  
  }