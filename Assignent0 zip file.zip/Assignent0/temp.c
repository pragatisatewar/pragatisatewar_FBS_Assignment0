#include <stdio.h>

   void main() {
    float Celsius, Fahrenheit; 

    printf("Enter the Temperature in Celsius: ");
    scanf("%f", &Celsius); 

    Fahrenheit = (Celsius * 9 / 5) + 32; 

    printf("Temperature in Fahrenheit: %.2f\n", Fahrenheit); 

    
}
