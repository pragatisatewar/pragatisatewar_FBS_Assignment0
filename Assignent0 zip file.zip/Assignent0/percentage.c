#include<stdio.h>
   void main(){
    int maths,physics,chemistry,bio,science,sum ,total;
    float percentage;
   	 
   	 maths = 50;
   	 physics=45;
   chemistry=68;
    bio   =90;
    science=67;
    
    sum = maths+physics+chemistry+bio+science;
    total = sum;
    
     percentage =(sum/500.0)*100;//Assuming each subject is out of 100
     
     
     printf("Total=%d\npercentage= %.2f%%",total,percentage);
}