#include <stdio.h>

  void main() {
    int n, i, num, rem, digits, sum;

    printf("Enter the range (n): ");
    scanf("%d", &n);

    printf("Armstrong numbers between 1 and %d are:\n", n);

    for(i = 1; i <= n; i++) {
        num = i;
        sum = 0;

        
        digits = 0;
        int temp = num;
        while(temp > 0) {
            digits++;
            temp /= 10;
        }

        
        temp = num;
        while(temp > 0) {
            rem = temp % 10;
            sum += pow(rem, digits);
            temp /= 10;
        }

        
        if(sum == num) {
            printf("%d\n", num);
        }
    }


}
